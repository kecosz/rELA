#'Energy landscape analysis in parallel mode
#'@description Estimating stable state and tipping point
#'@param sa : sa is the output of runSA function.
#'@param SS.itr : SS.itr is a integer of iterator of stable state estimate.
#'@param FindingTip.itr : SS.itr is a integer of iterator of tipping points estimate.
#'@useDynLib rELA, .registration=TRUE
#'@importFrom Rcpp sourceCpp
#'@importFrom foreach foreach
#'@export
ELA <- function(sa=sa, env=NULL, SS.itr=20000, FindingTip.itr=10000,
                 threads=1, reporting=TRUE){
  ######################
  sadim <- dim(sa[[1]])
  na <- rownames(sa[[1]])
  if(sadim[2] > sadim[1]+1){
      if(length(env)==0){env <- rep(0, sadim[2]-sadim[1]-1)} ## !!!
        hestp <- sa[[1]][, 1] %>% 'names<-'(na)
        jestp <- sa[[1]][, ((sadim[2]-sadim[1])+1):sadim[2]] %>% 'dimnames<-'(list(na,na))
        gestp <- sa[[1]][,2:(sadim[2]-sadim[1])]  %>% 'dimnames<-' (list(na,colnames(env)))
        hhestp <- (hestp + gestp %*% env)[,1]
  }else{
        hestp <- sa[[1]][, 1] %>% 'names<-'(na)
        jestp <- sa[[1]][, -1] %>% 'dimnames<-'(list(na,na))
        gestp <- NULL
        hhestp <- hestp
  }
  ####################
  ## ||||||||||||||||||||||||||||||||||||| ##
  if(reporting){cat('Start ELA:\n')}
  start <- proc.time()[3]
	speciesName <- rownames(jestp)

	## ||||||||||||||||||||||||||||||||||||| ##
	## -- Stable state estimatin
	minsets <- SSestimate(hhestp, jestp, itr = SS.itr)
	minsets <- unique(floor(minsets*(10^8))/(10^8))
  colnames(minsets) <- c(speciesName, "energy")
  if(reporting){cat(nrow(minsets),"stable states were found.\n")}
	uniqueSS <- data.frame(minsets)
	sampleSS <- uniqueSS[order(uniqueSS$energy),]
	minsets <- as.matrix(sampleSS[order(sampleSS[, ncol(sampleSS)]), ])
	ssid <- sprintf("SS_%s", formatC(1:nrow(minsets), width = nchar(ncol(minsets)),
	                                 flag = "0"))
	rownames(minsets) <- ssid

	## ||||||||||||||||||||||||||||||||||||| ##
	## -- Tipping point estimation

	if(length(ssid)>1){
	comb = expand.grid(1:nrow(minsets), 1:nrow(minsets))
	comb <- comb[comb[, 1] <comb[, 2], 2:1]

	tpnodeID <- sprintf("TPnode_%s", formatC(1:nrow(comb), width = nchar(nrow(comb)),
	                             flag = "0"))

    cluster = makeCluster(threads)
    registerDoParallel(cluster)
    on.exit(stopCluster(cluster))

  if(reporting){cat('Checking', nrow(comb), 'tipping points.\n')}
	FindTip <- foreach (k = 1:nrow(comb), .combine=rbind, .packages="rELA", .export="minsets")%dopar%{

	    minsetsub <- minsets[as.integer(comb[k, ]), ]
	    ss1 = minsetsub[1, -ncol(minsets)]
	    ss2 = minsetsub[2, -ncol(minsets)]

	    tippoint.tmp = FindingTippingpoint_cpp(s1 = ss1,  s2 = ss2,
	                                           alpha = hhestp, jj = jestp,
	                                           tmax = FindingTip.itr)

	    colnames(tippoint.tmp) <- c(speciesName, "energy")

	    ss <- data.frame(SS1=rownames(minsetsub)[1], SS1.energy=minsetsub[1,ncol(minsetsub)],
	               SS2=rownames(minsetsub)[2], SS2.energy=minsetsub[2,ncol(minsetsub)])
	    tp <- data.frame(TP=tpnodeID[k], tippoint.tmp)
	    return( cbind(ss, tp))
	}
	}

	## ||||||||||||||||||||||||||||||||||||| ##
	## -- Summarize
	if(length(ssid)>1){
	tpState <<- (FindTip[,-c(1:5)]);
	tpStateUni <- unique(floor(tpState*(10^8)))/(10^8)
	tpid <- sprintf("TP_%s", formatC(1:nrow(tpStateUni), width = nchar(nrow(tpStateUni)),
	                                 flag = "0"))
	rownames(tpStateUni) <- tpid

	stateInfo <- rbind(data.frame(stateID=rownames(minsets), state=rep('Stable state', nrow(minsets)), minsets),
	                   data.frame(stateID=rownames(tpStateUni), state=rep('Tipping point', nrow(tpStateUni)), tpStateUni))
	                   }
	                   else{
	                   stateInfo <- data.frame(stateID=rownames(minsets), state=rep('Stable state', nrow(minsets)), minsets)
	                   }

	# ||||||||||||||||||||||||||||||||||||| ##
	if(length(ssid)>1){
	Stable <- FindTip[,c(1:4)]

	tmp <- rownames(tpStateUni); names(tmp) <-apply(tpStateUni[,-ncol(tpStateUni)], 1, paste, collapse='')
	ordered <- apply(tpState[,-ncol(tpState)], 1, paste, collapse='')
	tpidVec <- tmp[ordered]

	network <- data.frame(Stable, TP=tpidVec, Tp.energy=FindTip[,ncol(FindTip)])
	elasummary <- list(stateInfo = stateInfo, network =network)
	}else{
	elasummary <- list(stateInfo = stateInfo, network =NULL)
	}

	# ||||||||||||||||||||||||||||||||||||| ##
	if(reporting==TRUE){cat("converting...\n")}
  elaconv <- elaconvert(elasummary)
  end <- proc.time()[3]
	if(reporting==TRUE){cat(sprintf("ELA: elapsed time %.2f sec\n", end - start))}
	return(elaconv)}


#'ELA convert
#'@description Converting output of ELA function
#'@param ela : output of ELA function.
#'@export
elaconvert <- function(ela){
  stablestates <- apply(ela$stateInfo[ela$stateInfo$state=='Stable state', 3:(length(colnames(ela$stateInfo))-1)],
                        1,
                        bin2id) |> as.vector()

  ssenergy <- ela$stateInfo[ela$stateInfo$state=='Stable state','energy']

  # number of stable state
  num_ss <- nrow(ela$stateInfo[grepl('SS', ela$stateInfo$stateID),])

  # ela$stateInfo$stateID �̌���. ELAparallel(runELA.R) �� ssid ���������Q��.

  num_d <- nchar(ncol(ela$stateInfo)-2)
  get_tp <- function(i, j) {
      ss1 <- sprintf("SS_%s", formatC(i, width = num_d,flag="0"))
      ss2 <- sprintf("SS_%s", formatC(j, width = num_d,flag="0"))
      return(ela$network[ela$network$SS1==ss1 & ela$network$SS2==ss2,
                        "TP"])}

  # tippingpoints
  if(num_ss>1){
  tippingpoints <- lapply(matrix(1:num_ss), function(i)
  apply(matrix(1:num_ss), 1, function(j) {
      tp <- get_tp(i, j)
      if(length(tp)==0){return("Inf")}
      bin <- ela$stateInfo[ela$stateInfo$stateID==tp, 3:(length(colnames(ela$stateInfo))-1)]
                                          return(apply(bin,1, bin2id))
                                          })) %>% 'names<-'(sapply(1:num_ss, \(i) paste(i, sep="")))
  }else{
      tippingpoints <- lapply(matrix(1:1),function(i) apply(matrix(1:1),1, function(j) {
      return("Inf")
      })) %>% 'names<-'(sapply(1:1, \(i) paste(i, sep="")))
  }

  ## tpenergy
  if(num_ss>1){
  tpenergy <- lapply(matrix(1:num_ss),function(i) apply(matrix(1:num_ss),1, function(j) {
      tp <- get_tp(i, j)
      if(length(tp)==0){return(Inf)}
      return(ela$stateInfo[ela$stateInfo$stateID==tp, 'energy'])
      })) %>% 'names<-'(sapply(1:num_ss, \(i) paste(i, sep="")))
  }else{
      tpenergy <- lapply(matrix(1:1),function(i) apply(matrix(1:1),1, function(j) {
      return(Inf)
      })) %>% 'names<-'(sapply(1:1, \(i) paste(i, sep="")))
  }

  return(list(stablestates, ssenergy, tippingpoints, tpenergy))}


#'ELPruning
#'@description Pruning shallow basins of energy landscape
#'@param ela : output of ELA function.
#'@param th : th is a threshold which the range is 0 to 1.
#'@importFrom foreach foreach
#'@export
ELPruning <- function(ela, th=0.05, threads=1, reporting=TRUE){
  start <- proc.time()[3]
  if(reporting){cat('Start pruning:\n')}

  cluster = makeCluster(threads)
  registerDoParallel(cluster)
  on.exit(stopCluster(cluster))

  tss <- ela[[1]]
  tssen <- ela[[2]]
  tti <- ela[[3]]
  ttien <- ela[[4]]
  if(length(tss)>1){
      rat <- as.data.frame(permutations(
          n=length(tss), r=2, v=1:length(tss), repeats.allowed = TRUE)) %>% subset(
            V1 < V2)
      if(reporting==TRUE){cat("*")}
      cmpax <- calc_mist_pax(rat, ttien, tssen)
      if(reporting==TRUE){cat(".")}
      mist <- as.numeric(unlist(cmpax[,(dim(cmpax)[2]-1):(dim(cmpax)[2])]))
      pax <- cmpax[,-dim(cmpax)[2]:-(dim(cmpax)[2]-1)]
      paxmax <- max(mist)
      ssrep <- tss
      tss0 <- tss
      tt <- 0
  while(min(pax['val1']) < th * paxmax && length(tss) > 1){
      tt <- tt + 1
      rat <- as.data.frame(permutations(
          n=length(tss), r=2, v=1:length(tss), repeats.allowed = TRUE)) %>% subset(
            V1 < V2)
      cmpax <- calc_mist_pax(rat, ttien, tssen)
      if(reporting==TRUE){if(tt%%10 == 0){cat("*")}else{cat(".")}}
      mist <- as.numeric(unlist(cmpax[,(dim(cmpax)[2]-1):(dim(cmpax)[2])]))
      pax <- cmpax[,-dim(cmpax)[2]:-(dim(cmpax)[2]-1)]
      paxmax <- max(mist)
    if(min(pax['val1']) >= th * paxmax){
      break
      }else{
        pp <- pax[order(pax$val1),][1, c('val2_1', 'val2_2')] %>% as.list() %>% unlist()
        ssrep <- replace_value(tss[pp[2]], ssrep, tss[pp[1]])
        tss <- tss[tss != tss[pp[2]]]
        tssen <- tssen[tssen != tssen[pp[2]]]
        tti_pre <- tti %>% as.data.frame()
        tti <- tti_pre[rownames(tti_pre) != rownames(tti_pre)[pp[2]],
                       colnames(tti_pre) != colnames(tti_pre)[pp[2]]] %>% as.list()
        ttien_pre <- ttien %>% as.data.frame()
        ttien <- ttien_pre[rownames(ttien_pre) != rownames(ttien_pre)[pp[2]],
                           colnames(ttien_pre) != colnames(ttien_pre)[pp[2]]] %>% as.list()
      }
    if(length(ssrep) == 1){break}
  }
  tti <- tti %>% as.data.frame() %>% 'colnames<-'(1: length(tti)) %>% as.list()
  ttien <- ttien %>% as.data.frame() %>% 'colnames<-'(1: length(ttien)) %>% as.list()
  end <- proc.time()[3]
  if(reporting==TRUE){cat(sprintf("\nELPruning: elapsed time %.2f sec\n", end - start))}
  return(list(list(tss, tssen, tti, ttien), cbind(tss0, ssrep)))
  }else{
  end <- proc.time()[3]
  if(reporting==TRUE){cat(sprintf("\nELPruning: elapsed time %.2f sec\n", end - start))}
  return(list(list(tss, tssen, tti, ttien), cbind(tss, tss)))
  }}


#'Calc mist pax
#'@description supporting function for ELpruning
#'@importFrom foreach foreach
#'
calc_mist_pax <- function(rat, ttien, tssen){
  pax <- rat
  npax <- max(pax['V2'])
  ttien.m <- as.matrix(ttien)
  
  a <- foreach(i = pax[,'V1'], j = pax[,'V2'], .combine="rbind", .export="pax", .packages=c("tidyverse","rELA")) %dopar% {
    row_ <- as.character(npax*(i-1) + j)
    te <- ttien.m[[j]][i]
    se <- c(tssen[i], tssen[j])
    pax[row_, 'val1'] <- min(te - se[1], te - se[2])
    val2_pre <- pax[row_, c('V1', 'V2')] %>% T %>% cbind(se)
    val2_pre <- val2_pre[order(val2_pre$se)][,row_]
    pax[row_, 'val2_1'] <- val2_pre[1]
    pax[row_, 'val2_2'] <- val2_pre[2]
    pax[row_, 'mist1'] <- te - se[1]
    pax[row_, 'mist2'] <- te - se[2]
    pax[row_,]
    }
  return(a)}

#'Replace value
#'@description supporting function for ELpruning
#'
replace_value <- function(value_before, list_before, value_after){
  list_after <- list_before
  for(i in 1: length(list_after)){
    if(list_after[i] == value_before){list_after[i] <- value_after}
  }
  return(list_after)
}


#'SteepestDescent
#' @useDynLib rELA, .registration=TRUE
#' @export
SteepestDescent <- function(state, alpha, beta){
	res <- SteepestDescent_cpp(state, alpha, beta)
	return(res)
}

#'Bi
#' @useDynLib rELA, .registration=TRUE
#' @export
Bi <- function(xi, h, j){
  sd <- SteepestDescent(xi,h,j)
  stateyen <- list(as.vector(sd[-length(sd)]), sd[length(sd)])
  state <- stateyen[[1]]
  energy <- stateyen[[2]]
  return(
    list(bin2id(state),
      energy))}

#'cEnergy
#' @export
cEnergy <- function(x, h, j){
  return(
    (- unlist(x) %*% unlist(h) - as.vector(unlist(as.vector(x))) %*%
       as.vector((unlist(x) %*% j) / 2))[1, 1]
    )
}

#'Energy
#' @useDynLib rELA, .registration=TRUE
#' @export
Energy <- function(state, alpha, beta){
	res <- cEnergy(state, alpha, beta)
	return(res)
}


#'GradELA
#'@description Estimate energy landscape across environmental gradients
#'
#'@useDynLib rELA, .registration=TRUE
#'@export
GradELA <- function(sa=sa, eid=NULL, env=envecs, refenv=NULL, steps=16, th=0.05, threads=1){
  start <- proc.time()[3]
  if(is.null(eid)){return(cat("eid not specified prease set eid=position/colname\n"))}
  if(is.character(eid)){ei <- which(colnames(env)==eid)}else{ei<-eid}
  if(is.null(refenv)){refe <- apply(env, 2, mean)
  cat("refenv not specified, the mean of envecs is used\n")
  }else{refe <- refenv}
  mi <<- min(env[,ei])
  ma <<- max(env[,ei])
  dm <<- (ma - mi)/(steps - 1)
  de <- seq(mi, ma, dm)
  cat("processing(")
  cat(length(de))
  cat(") |")
  els <- foreach(i=de) %do% {
      cat("=")
      ee <- replace(refe,ei,i)
      elanp <- ELA(sa, ee, threads=threads, reporting=FALSE)
      ELPruning(elanp, th, reporting=FALSE)
  }
  cat("|\n")
	end <- proc.time()[3]
  cat(sprintf("Elapsed time %.2f sec\n", end - start))
  return(list(els, de, colnames(env)[ei]))
}


#'SSentropy
#' @useDynLib rELA, .registration=TRUE
#' @export
SSentropy <- function(state, ss,
          				alpha, beta, 
          				seitr=1000, convTime=10000){
	res <- SSentropy_cpp(uoc= state, ss= ss,
          				alpha= alpha, beta=beta, 
          				seitr=seitr, convTime=convTime)
	return(res)
}


#'stability
#'@description Calculate energy gap and stable state entropy as stability indices
#'
#' @useDynLib rELA, .registration=TRUE
#' @export
stability <- function(sa, ocvecs, convTime=10000){
  sa2pa <- sa2params(sa)
  je <- sa2pa[[2]]
  hge <- sa2pa[[4]]
  sampleSS <- t(apply(ocvecs, 1, SteepestDescent, alpha=hge, beta=je))
  sse <- SSentropy(ocvecs, ss=unique(sampleSS[,-ncol(sampleSS)]), alpha= hge, beta=je, seitr=1000, convTime)
  if(sum(sse[,3])>1){cat("convTime may be too small, try convTime>10000.\n")}
  ssentropy <- sse[,1]
  names(ssentropy) <- rownames(ocvecs)
  ssenergy <- sampleSS[, ncol(sampleSS)]
  energy <- apply(ocvecs, 1, cEnergy, hge, je)
  energy.gap <- energy-ssenergy
  cbind(energy.gap, ssentropy)
}



####################################
####################################

#'Calculation stability indices.
#'@description Claculating stable state energy, difference between sample's energy and stable state energy and stable state entropy.
#'
#'@param data : data is a matrix.
#'@param alpha : alpha is a vector which explicit/implicit preference. Use output of runSA function.
#'@param J : J is a matrix which shows species preference. Use output of runSA function.
#'@param 
#'
#' @useDynLib rELA, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @export
calcStability <- function(data=NULL, alpha, J,
						  plun=0,
						  seitr=1000, convTime=10000){
						  	
    start <- proc.time()[3]
    sampleSS <- t(apply(data, 1, SteepestDescent_cpp, alpha=alpha, beta=J))
   	
   	uniqueSS <- data.frame(unique(sampleSS[,-ncol(sampleSS)]))
	uniqueSS$energy <- NA
	
	for(i in 1:nrow(uniqueSS)){
	    
	    state <- uniqueSS[i,-ncol(uniqueSS)]
	    detect <- apply(sampleSS[,-ncol(sampleSS)], 1, function(x){ all(x==state) })
	    
	    uniqueSS[i, ncol(uniqueSS)] <- mean(sampleSS[detect, ncol(sampleSS)])
	}
	sampleSS <- uniqueSS[order(uniqueSS$energy),]
	
    ## ================================ ##
	if(plun>0){
		
		## |||||||||||||||||||||||||||| ##
		## plunned landscape
	    elasummary <- ELAparallel(alpha=res[,1], J=res[,-1], threads=8)
		redela <- ELplunning(elasummary, th=0.1)
		
		stateInfo <- elasummary[[1]]
		ssInfo <- stateInfo[stateInfo$state=='Stable state',]
		
		## |||||||||||||||||||||||||||| ##
		## -- Convert to deeper landscape
		
		sampleSSpluned <- as.matrix(sampleSS)
		for(i in 1:nrow(ssInfo)){
		    
		    state <- ssInfo[i,-c(1, 2, ncol(ssInfo))]
		    detect <- apply(sampleSS[,-ncol(sampleSS)], 1, function(x){ all(x==state) })
		    
		    if(sum(detect)>1){
		        id <- ssInfo[i,1]
		        
		        if( !any(redela$log[,2]==id)){
		            log <- redela$log
		            change <- log[id,2]
		            
		            sampleSSpluned[detect,] <- matrix( unlist(ssInfo[change, -c(1,2)]), 
		            								   ncol=ncol(sampleSStmp), nrow=sum(detect), 
		            								   byrow=TRUE)
		        }
		        
		    }
		
		}
		sampleSS <- sampleSSpluned
        ## |||||||||||||||||||||||||||| ##
	}
    
    stablestate=t(apply(sampleSS, 1, 
                    function(x){ 
                        sep <- round(length(x)/20)
                        line <- c()
                        for(i in 1:sep){
                            y <- x[-length(x)]
                            bi <- na.omit(y[((1+20*(i-1)):(20*i))])
                            line <- c(line, str2i( paste0(bi, collapse='')))
                            
                        }
                        
                        ssid=paste(line, collapse='-')
                        c(ssid, x[length(x)]) }))
                  
    ssenergy <- sampleSS[, ncol(sampleSS)]
    energy <- apply(data, 1, cEnergy, alpha= alpha, beta=J)
    
    energy.gap <- energy-ssenergy
    ssent <- SSentropy_cpp(uoc=data, ss=unique(sampleSS[,-ncol(sampleSS)]),
          				alpha= alpha, beta=J, 
          				seitr=seitr, convTime=convTime)
          	  
    return( data.frame(StableState.id=stablestate[,1], SSenergy=ssenergy,
                       energy.gap=energy.gap, SSentropy= ssent[,1]))
                       
    ## ================================ ##
    end <- proc.time()[3]
    cat(sprintf('Stability calculation done.\nElapsed time %.2f sec\n\n', end-start))                   
}

#'ELAall 
#'@description Run all ELA pipeline
#'@param data : data is a binary matrix.
#'@param alpha : alpha is a vector which explicit/implicit preference. Use output of runSA function.
#'@param J : J is a matrix which shows species preference. Use output of runSA function.
#'@param 
#'
#' @useDynLib rELA, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @export
ELAall <- function( data=NULL, alpha, J,
				    SS.itr=20000, FindingTip.itr=10000,
					plun=0,
					seitr=1000, convTime=10000,
					threads=1){
						  	
    start <- proc.time()[3]
    
   	elasummary <- ELAparallel(alpha=res[,1], J=res[,-1], 
   							  SS.itr= SS.itr, FindingTip.itr=10000, threads=threads)
   	
    ## ================================ ##    
    sampleSS <- t(apply(data, 1, SteepestDescent_cpp, alpha=alpha, beta=J))
   	
	if(plun>0){
		
		## |||||||||||||||||||||||||||| ##
		## plunned landscape
	    
		redela <- ELplunning(elasummary, th= plun)
		
		stateInfo <- elasummary[[1]]
		ssInfo <- stateInfo[stateInfo$state=='Stable state',]
		
		## |||||||||||||||||||||||||||| ##
		## -- Convert to deeper landscape
		
		sampleSSpluned <- as.matrix(sampleSS)
		ssid <- rep(NA, nrow(sampleSS))
		for(i in 1:nrow(ssInfo)){
		    
		    state <- ssInfo[i,-c(1, 2, ncol(ssInfo))]
		    detect <- apply(sampleSS[,-ncol(sampleSS)], 1, function(x){ all(x==state) })
		    ssid[detect] <- rownames(ssInfo)[i]
        
            if(sum(detect)>1){
		        id <- ssInfo[i,1]
		        
		        if( !any(redela$log[,2]==id)){
		            log <- redela$log
		            change <- log[id,2]
		            
		            sampleSSpluned[detect,] <- matrix( unlist(ssInfo[change, -c(1,2)]), 
		            								   ncol=ncol(sampleSSpluned), nrow=sum(detect), 
		            								   byrow=TRUE)
		        }
		        
		    }
		
		}
		sampleSS <- sampleSSpluned
        ## |||||||||||||||||||||||||||| ##
	}
                      
    ssenergy <- sampleSS[, ncol(sampleSS)]
    energy <- apply(data, 1, cEnergy, alpha= alpha, beta=J)
    
    energy.gap <- energy-ssenergy
    ssent <- SSentropy_cpp(uoc=data, ss=unique(sampleSS[,-ncol(sampleSS)]),
          				alpha= alpha, beta=J, 
          				seitr=seitr, convTime=convTime)
          	  
    stability=data.frame(StableState.id=ssid, SSenergy=ssenergy,
                     energy.gap=energy.gap, SSentropy= ssent[,1])


	return( list(elaResult=elasummary, elaPlunning=redela, stability=stability ))
                    
    ## ================================ ##
    end <- proc.time()[3]
    cat(sprintf('Stability calculation done.\nElapsed time %.2f sec\n\n', end-start))                   
}