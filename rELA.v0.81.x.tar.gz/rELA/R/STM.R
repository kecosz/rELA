#'align_inputs_stm
#'@description Function of STM: aligning environmental and occurence matrices
align_inputs_stm <- function(ocmat, enmat) {
  stopifnot(is.matrix(ocmat) || is.data.frame(ocmat))
  stopifnot(is.matrix(enmat) || is.data.frame(enmat))
  stopifnot(!is.null(rownames(ocmat)), !is.null(rownames(enmat)))
  ids <- intersect(rownames(ocmat), rownames(enmat))
  if (length(ids) < nrow(ocmat) || length(ids) < nrow(enmat)) {
    warning("Some indices only appeared in either of environmental and occurence matrices.")
  }
  ocm <- ocmat[ids, , drop = FALSE]
  meta <- enmat[ids, , drop = FALSE]
  
  # check binary
  #if (!all(ocm %in% c(0, 1))) stop("Input ocmat is not a binary(0/1) matrix.")
  
  # meta(environmental) data：character -> factor
  for (cn in colnames(meta)) {
    if (is.character(meta[[cn]])) {
      meta[[cn]] <- factor(meta[[cn]])
    }
    # convert logical parameter to integer
    if (is.logical(meta[[cn]])) {
      warning(paste0(cn," : metadata have a logical value and are converted to integer."))
      meta[[cn]] <- as.integer(meta[[cn]])
    }
  }
  list(ocm = ocm, meta = meta)
}

#'to_stm_corpus
#'@description Function for converting to corpus object
#'
to_stm_corpus <- function(ocm) {
  # convert to dfm（row=sample、col=feature）
  dfm_obj <- as.dfm(ocm)
  conv <- quanteda::convert(dfm_obj, to = "stm")  # list(documents, vocab, meta=NULL)
  conv
}


#'to_stm_corpus
#'@description Function for converting to corpus object
#'
make_formulas <- function(meta, content_var = NULL, include_content_var = FALSE) {
  if(include_content_var){
    rhs <- paste(colnames(meta), collapse = " + ")
  }else{
    rhs <- paste(colnames(meta)[colnames(meta) != content_var], collapse = " + ")
  }
  rhs <- paste(colnames(meta), collapse = " + ")
  prevalence_fm <- as.formula(paste("~", rhs))
  content_fm <- if (is.null(content_var)) NULL else as.formula(paste("~", content_var))
  list(prevalence = prevalence_fm, content = content_fm)
}


#'auto_select_K_heldout
#'@description Select the number of optimal assemblages(K) in STM by heldout parameter.
#'@
#'
auto_select_K_heldout <- function(stm_mat, taxa, data,
                                  prevalence = ~1,K_grid = 3:8,
                                  init.type = c("Spectral","LDA","Random")[1],
                                  max.em.its = 150, seed = 1) {
  
  set.seed(seed)
  # init.type==Spectral: K < |taxa|
  V <- length(taxa)
  if (init.type == "Spectral") {
    K_grid <- K_grid[K_grid < V]
    if (length(K_grid) == 0) stop("When init.type='Spectral', K < |taxa| must be satisfied. Check K_grid.")
  }
  
  # use searchK function in STM
  sk <- stm::searchK(documents = stm_mat,
                     vocab      = taxa,
                     K          = K_grid,
                     prevalence = prevalence,
                     content    = NULL,
                     data       = data,
                     init.type  = init.type,
                     max.em.its = max.em.its,
                     verbose    = FALSE,
                     seed       = seed)
  sk_results <- sk$results
  k_opt <- sk_results$K[which.max(sk_results$heldout)]
  if (length(k_opt) > 1) k_opt <- min(k_opt)
  
  list(k_opt = k_opt, summary = sk_results)
}


#'stm_for_ela
#'@description Run STM using optimal assemblage numbers (K)
#'
#'@param abdata : taxa abundance data (without binarization)
#'@param metadata : environmental factor data
#'@param M: multiplied factors for converting to interger matrix
#'@param K_grid : array of Ks used for searching optimal clusters (K)
#'@param K_fixed: (integer) used for stm.if NULL, optimal K will be searched using K_grid.
#'@param content_var: the values in content_var should be categorical indices (not numerical)
#'@param seed : the random seed for clustering.
#'@param Normalize : (bool) If true, the data will be normalized so that the sum of each row is 1.
#'@param train_idx : indices used for training.
#'@param include_content_var : (bool) If TRUE, the content_var is also used as a prevalence covariate.
#'@param maxit : the maximum iterations.
#'@returns k_opt: used K for stm
#'@returns theta : sample-assemblage matrix
#'@returns beta : assemblage-taxa matrix)
#'----
stm_for_ela <- function(abdata, metadata, M=1000,
                        K_grid = 3:8,
                        K_fixed = NULL,             
                        content_var = NULL,
                        train_idx =NULL,
                        Normalize =TRUE,
                        include_content_var=FALSE,
                        seed = 1234,
                        init.type = c("Spectral","LDA","Random")[1],
                        maxit = 150) {
  
  # create stm object and formulae
  count_mat <- preprocessing_LDA(abdata,M=M,train_idx = train_idx,Normalize = Normalize)
  inputs <- align_inputs_stm(count_mat$data,metadata)
  ocvecs <- inputs[[1]]
  envecs <- inputs[[2]]
  stm_oc <- to_stm_corpus(ocvecs)
  fm <- make_formulas(envecs,content_var = content_var)
  
  # seearch optimal K
  if (is.null(K_fixed)) {
    k_stats <- auto_select_K_heldout(stm_oc$documents, stm_oc$vocab, 
                                     envecs, prevalence = fm$prevalence, 
                                     K_grid = K_grid,
                                     init.type = init.type,
                                     max.em.its = maxit, seed = seed)
    k_opt <- k_stats$k_opt[[1]]
    message(sprintf("Selected K = %d (by held-out)", k_opt))
  } else {
    k_opt <- K_fixed
  }
  set.seed(seed)
  
  #run stm 
  fit <- stm(documents = stm_oc$documents, vocab = stm_oc$vocab,
             K = k_opt, prevalence= fm$prevalence, content=fm$content,
             data = envecs, max.em.its = maxit, init.type = init.type,
             verbose=FALSE)
  
  # theta: sample x cluster
  theta <- fit$theta
  theta[theta <= 1e-10] <- 0
  rownames(theta) <- rownames(ocvecs)
  colnames(theta) <- paste0("Cluster.", seq_len(ncol(theta)))
  
  # beta: cluster x taxa（without content covariate）
  if (is.null(fm$content)) {
    beta <- exp(fit$beta$logbeta[[1]])  # K x V
    rownames(beta) <- colnames(theta)
    colnames(beta) <- stm_oc$vocab
    beta[beta <= 1e-10] <- 0
  } else {
    beta <- list()
    for (i in 1:length(fit$beta$logbeta)){
      beta_i <- exp(fit$beta$logbeta[[i]])
      rownames(beta_i) <- colnames(theta)
      colnames(beta_i) <- stm_oc$vocab
      beta_i[beta_i <= 1e-10] <- 0
      beta[[i]] <- beta_i
    }
  }
  
  list(k_summaryの = k_stats,
       theta = theta,   # samples x cluster
       beta  = beta  # cluster x taxa
       )
}


#'bin_continuous
#'@description Binning continuous parameters
#'
#'@param meta : environmental variable table
#'@param var: variable name
#'@param n_bins: the number of bins
#'@param method: binning method (quantile, equal, or custom(used with binrange))
#'@param binrange: custom binning sequence (array)
#'@param new_col: new col name
#'@param labels: labels for bins
bin_continuous <- function(meta, var, n_bins = 3, method = c("equal","quantile","custom"), 
                           binrange=c(0,0.25,0.5,0.75,1), new_col = NULL, labels = NULL) {

  method <- match.arg(method)
  x <- meta[[var]]
  
  # eliminate NA 
  if (method == "quantile") {
    breaks <- quantile(x, probs = seq(0, 1, length.out = n_bins + 1), na.rm = TRUE)
  } else if(method=="equal") {
     breaks <- seq(min(x, na.rm = TRUE), max(x, na.rm = TRUE), length.out = n_bins + 1)
  }
  else{
    breaks <- binrange
  }
  
  breaks[1] <- breaks[1] - 1e-8
  breaks[length(breaks)] <- breaks[length(breaks)] + 1e-8
  
  # create labels
  if (is.null(labels)) {
    labels <- paste0("Bin", seq_len(n_bins))
  }
  
  # row names
  if (is.null(new_col)) {
    new_col <- paste0(var, "_bin")
  }
  
  # categorize
  meta[[new_col]] <- cut(x, breaks = breaks, labels = labels, include.lowest = TRUE, ordered_result = TRUE)
  list(meta,breaks)
}
