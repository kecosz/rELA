#' logmon: supporting function for heat bath
#' @export
logmon <- function(y, h, J, g=NULL, enmat=NULL) {
  si <- y %*% J
  if(is.null(enmat)){
    term <- t(sweep(-si,2,h,FUN = "-"))
  }else{
    gei <- enmat %*% t(g) 
    hei <- sweep(gei,2,h,FUN="+")
    term <- t(-hei - si)
  }
  result <- 1 / (1 + exp(term))
  return(result)
}

#' OnestepHBS: one step heat bath sampling
#' @export
OnestepHBS <- function(y, logmo) {
  n <- nrow(y)
  m <- ncol(y)
  # Function to update one row of y
  update_row <- function(row_y, row_logmo) {
    position <- sample(1:m, 1)  # Randomly choose a position
    ne <- ifelse(runif(1) < row_logmo[position], 1, 0)  # Compare with logmo
    row_y[position] <- ne  # Update the chosen position
    return(row_y)
  }
  # Apply the update_row function to each row
  updated_y <- t(mapply(update_row, as.data.frame(t(y)), as.data.frame(t(logmo))))
  
  return(updated_y)
}

#' HeatBath: HeatBath sampling
#' @export
HeatBath <- function(steps, nproc, h, J, g = NULL) {
  nn <- length(h)
  speciesname <- lapply(seq_len(nn),function(i){return(paste("species.",i,sep=""))})
  samplename <- lapply(seq_len(nproc),function(i){return(paste("sample.",i,sep=""))})
  y <- array(0, dim = c(nproc, nn),dimnames=list(samplename,speciesname))
  if(!is.null(g)){
    ne <- dim(g)[2]
    factorname <- lapply(seq_len(ne),function(i){return(paste("factor.",i,sep=""))})
    enmat <- matrix(runif(nproc * ne, min=0,max=1), nrow = nproc, ncol = ne,
                    dimnames=list(samplename,factorname))
  }else{enmat <- NULL}
  for (i in 1:steps){ 
    logmo <- logmon(y, h = h, J = J, g = g, enmat = enmat)
    y <- OnestepHBS(y, t(logmo))
  }
  colnames(y) <- speciesname
  return(list(y,enmat))
}

#' random generation of parameters
#' @export
hb.paramgen <- function(nn,ne=0,j_connectivity=1){
  speciesname <- lapply(seq_len(nn),function(i){return(paste("species.",i,sep=""))})
  jname <- lapply(speciesname,function(i){return(paste("J.",i,sep=""))})
  h.act <- runif(nn, min = -2, max = 2) %>% 'names<-'(speciesname)
  rnp <- function() {
    tuples <- t(combn(nn, 2))
    rnp_list <- lapply(seq_len(nrow(tuples)), function(i) {
      if (runif(1) < 0.5) {
        return(rev(tuples[i, ]))
      } else {
        return(tuples[i, ])
      }
    })
    return(do.call(rbind, rnp_list))
  }
  
  generate_matrix <- function(rnp_list) {
    nonzerolist <- sample(1:nrow(rnp_list),nrow(rnp_list)*j_connectivity)
    ma <- matrix(0, nn, nn)
    for (i in seq_len(nrow(rnp_list))) {
      index <- rnp_list[i, ]
      ma[index[1], index[2]] <- ifelse(i %in% nonzerolist, runif(1, min = -2, max = 2), 0)
    }
    return(ma)
  }
  
  rnp_list <- rnp()
  ma <- generate_matrix(rnp_list)
  j.act <- ma + t(ma) %>% 'dimnames<-'(list(speciesname,speciesname))
  if(ne>0){
    gname <- lapply(seq_len(ne),function(i){return(paste("g.",i,sep=""))})
    g.act <- matrix(runif(nn * ne, min=-2,max=2), nrow = nn, ncol = ne) %>% 
      'dimnames<-'(list(speciesname,gname))
    return(list(h.act,j.act,g.act))}
  else{return(list(h.act,j.act))}
}

#' Gradient Descent functionst
GradientDescent <- function(data, maxit) {
  units <- ncol(data)
  tdata <- t(data)
  e <- 10^-8
  datalength <- nrow(data)
  tuples <- as.matrix(expand.grid(rep(list(0:1), units)))
  lt <- nrow(tuples)
  
  semp <- colMeans(data)
  ssemp <- t(data) %*% data / datalength * abs(diag(units) - 1)
  htt <- rep(0, units)
  jtt <- matrix(0, units, units)
  ttt <- 0
  while (ttt < maxit) {
    ht <- htt
    jt <- jtt
    e0 <- apply(tuples, 1, Energy, htt, jtt)
    en <- exp(-e0)
    etot <- sum(en)
    prb <- en / etot
    pt <- prb * tuples
    smod <- colSums(pt)
    ssmod <- (t(pt) %*% tuples) * abs(diag(units) - 1)
    dh <- 0.1 * ((semp + e) - (smod + e))
    dj <- 0.1 * ((ssemp + e) - (ssmod + e))
    htt <- ht + dh
    jtt <- jt + dj
    ttt <- ttt + 1
  }
  
  list(h.est = htt, j.est = jtt)
}