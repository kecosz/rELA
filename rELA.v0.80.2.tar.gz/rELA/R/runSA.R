#'Stochastic Approximation
#'@description Estimating species interaction, environemnt preference.
#'
#'@param ocmat : array of the vectors of presence/absence status for each sample. Row is sample, column is species.
#'@param enmat : array of the vectors of environmental factors for each sample. Normalization required.
#'@param we : the parameter for adamW.
#'@param lambda : the parameter for sparse matrix
#'@param rep : number of parallel processes for the optimization.
#'@param intv : interval of iterations recording intermediate fitting results.
#'@param totalit : total iterations of optimization
#'@param threads : number of cores (threads) used for calculation. 
#'@param getall : If TRUE, the function returns all intermediate results
#'@param reporting : enable/disable the reporting function.
#'
#' @useDynLib rELA, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom foreach foreach
#' @export
runSA <- function(ocmat, enmat=NULL,  rep=128, threads=1, we=0.001, 
                  totalit=1000, lambda=0.01,intv=100, runadamW=TRUE,
                  maxlr = 0.005, sparse=TRUE, getall=FALSE, reporting=TRUE){
    
    if(!sparse){lambda <- 0}
  
    #if(!runadamW){we <- 0}
  
    if(threads>1){cluster = makeCluster(threads)
    clusterCall(cluster, function(x) .libPaths(x), .libPaths())
    registerDoParallel(cluster)
    on.exit(stopCluster(cluster))}

    if(is.null(enmat)){

    	## ============================================== ##
        ## -- without explicit variables

        if(reporting){cat('Start parameter fitting:\n')}
        s <- proc.time()[3]
        if(threads>1){fittingMat <- foreach(i = 1:rep, .packages="rELA") %dopar% {
            SAres <- SA(ocData = ocmat, we = we, totalit = totalit, 
                        runadamW = runadamW, sparse = sparse,
                        lambda = lambda, intv = intv, maxlearningrate = maxlr)
            return(SAres)
        }}else{fittingMat <- foreach(i = 1:rep) %do% {
	      if(reporting){cat('.')}
            SAres <- SA(ocData = ocmat, we = we, totalit = totalit, 
                        runadamW = runadamW, sparse = sparse,
                        lambda = lambda, intv = intv,maxlearningrate = maxlr)
            return(SAres)
        }}

        if(reporting){cat(sprintf('SA: elapsed time %.2f sec\n\n', proc.time()[3]-s))}
        ## ============================================== ##
      
        if(getall){
          return(fittingMat)
        }else{
            return(list(saEndpoint(fittingMat,ocmat),enmat))}
          
	    }else{

        ## ============================================== ##
        ## -- with explicit variables

        if(reporting){cat('Start parameter fitting\n')}
        s <- proc.time()[3]
        if(threads>1){fittingMat <- foreach(i = 1:rep, .packages="rELA") %dopar% {
            SAres <- fullSA(ocData = ocmat, envData=as.matrix(enmat), 
                            runadamW = runadamW, sparse = sparse, we = we, 
                            totalit = totalit, lambda = lambda, intv = intv,
                            maxlearningrate = maxlr)
            return(SAres)
        }}else{fittingMat <- foreach(i = 1:rep) %do% {
            if(reporting){cat('.')}
            SAres <- fullSA(ocData = ocmat, envData=as.matrix(enmat),
                            runadamW = runadamW, sparse = sparse, we = we, 
                            totalit = totalit, lambda = lambda, intv = intv,
                            maxlearningrate = maxlr)
            return(SAres)
        }}

        if(reporting){cat(sprintf('SA: elapsed time %.2f sec\n\n', proc.time()[3]-s))}
        if(getall){
          return(fittingMat)
        }else{
          return(list(saEndpoint(fittingMat,ocmat,enmat=enmat),enmat))}
        ## ============================================== ##
	
    }
}


#'saEndpoint: extract endpoint parameters from runSA output
#' @export
saEndpoint <- function(fittingMat,ocmat,enmat=NULL){
  
  num_cols <- ncol(ocmat)
  packed_results_end <- lapply(fittingMat, 
                               function(x) x[(nrow(x) - num_cols + 1):nrow(x),])
  params_all <- lapply(packed_results_end, function(x) x[, 1:(ncol(x) - 2)])
  #upd <- lapply(sa, function(x) x[, (ncol(x) - 1):ncol(x)]) 
  
  params_mat <- params_all[[1]]
  if (length(params_all)>1){
    for (n in 2:length(params_all)) {
      params_mat <- params_mat + params_all[[n]]
    }
  
    params_mat <- params_mat/length(params_all)
  }
  rownames(params_mat) <- colnames(ocmat)
  
  if(is.null(enmat)){
    colnames(params_mat) <- c("h",paste('J',colnames(ocmat),sep='.'))
  }
  else{
    encols <- ncol(enmat)
    
    if( ncol(as.matrix(enmat))==1 ){
      gname <- paste('g', colnames(enmat), sep='.')
      ncols <- ncol(ocmat)+2
    }else{
      gname <- paste('g',1:ncol(enmat), sep='.')
      ncols <- ncol(ocmat)+ncol(enmat)+1
    }
    
    colnames(params_mat) <- c('h', gname, paste('J',colnames(ocmat),sep='.'))
  }
  
  return(params_mat)
}


#'sa2paramss: extract model parameters from runSA output
#' @useDynLib rELA, .registration=TRUE
#' @export
sa2params <- function(sa, env=NULL){
  sadim <- dim(sa[[1]])
  na <- rownames(sa[[1]])
  if(sadim[2] > sadim[1]+1){
      if(length(env)==0){env <- rep(0, sadim[2]-sadim[1]-1)} ## !!!
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, ((sadim[2]-sadim[1])+1):sadim[2]] %>% 'dimnames<-'(list(na,na))
        ge <- as.matrix(sa[[1]][,2:(sadim[2]-sadim[1])])  %>% 'dimnames<-' (list(na,colnames(sa[[2]])))
        hge <- (he + ge %*% env)[,1]
        #hge <- t(t(envecs %*% t(ge)) + he)
  }else{
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, -1] %>% 'dimnames<-'(list(na,na))
        ge <- NULL
        hge <- he
  }
  return(list(he, je, ge, hge))}


#'testfittingSA: testrun of SA across given parameter sets using subset of ocmatrix
testfittingSA <- function(ocmat,sa_results,rep,intv,enmat=NULL){
  nspecies = ncol(ocmat)
  num_timepoints <- nrow(sa_results[[1]]) / nspecies -1
  timepoints <- sapply(0:num_timepoints, function(x) (x + 1) * intv)
  serials <- 1:rep
  res_serials <- matrix(0, ncol= (num_timepoints+1), nrow=rep,
                       dimnames=list(serials,timepoints))
  for(i in 1:length(sa_results)){
    rowidx <- 1
    timeidx <- 1
    SAparams <- sa_results[[i]]
    while(rowidx < nrow(SAparams)){
      
      params<-sa2params(list(SAparams[rowidx:(rowidx+nspecies-1),
                                                  1:(ncol(SAparams)-2)],enmat))
      res_serials[i,timeidx] <- validateSA(ocmat,params[[1]],params[[2]],
                                           g=params[[3]],enmat=enmat)
      rowidx <- rowidx + nspecies
      timeidx <- timeidx + 1
    }
  }
  return(res_serials)
}
  
#'Findbp: Search the best parameters for SA fitting. 
#'Specifically for lambda and we in adamW and Sparse.
#'If fastfitting=TRUE, then "the function returns 
#'the minimum iterations allowing less than +3% errors than the minimum error.
#' @export
Findbp <- function(ocmat,enmat=NULL,ssize=0.5,we=c(0.001),
                   totalit=4000,lmd=c(0.0005,0.001,0.0025,0.005,0.0075),
                   maxlr = 0.005,rep=96,intv=100,threads=16,
                   runadamW=TRUE,sparse=TRUE,reporting=FALSE,
                   fastfitting=TRUE){
  min_points <- list()
  n_samples <- nrow(ocmat)
  
  randidxs <- sample(n_samples, size = floor(n_samples * ssize), replace = FALSE)
  remaining <- setdiff(1:n_samples, randidxs)
  
  # divide into training and test datasets
  octraining <- ocmat[randidxs,]
  octest <- ocmat[remaining,]
  
  if(!is.null(enmat)){
    envtraining = enmat[randidxs,]
    envtest = enmat[remaining,]
  }
  else{envtest=NULL
       envtraining=NULL}
  
  if(!runadamW){we=c(0)}
  if(!sparse){lmd=c(0)}
  
  allresults = list()
  for(l in lmd){
    for(w in we){
      cat(sprintf("Try: lambda=%.6f, we=%.6f, runadamW=%s, Sparse=%s\n\n",l, w, runadamW, sparse))
      sa_results <- runSA(octraining, enmat=envtraining, rep=rep, threads=threads, we=w, 
                          totalit=totalit, lambda=l,intv=intv, runadamW=runadamW, 
                          sparse=sparse,maxlr=maxlr,getall=TRUE, reporting=reporting)
      current_results <- testfittingSA(octest,sa_results,rep,intv,enmat=envtest)
      if(fastfitting){
        mean_results <- apply(current_results, 2, mean)
        min_err <- min(mean_results) 
        
        top_results <- mean_results[mean_results < min_err*1.03]
        top_results <- top_results[order(as.numeric(names(top_results)))]
        top_results <- top_results[1:min(length(top_results),5)]
        
        for (m in names(top_results)){
          min_points[[paste(l, w, as.integer(m), sep = "_")]] <- as.numeric(top_results[m])
        }
      }else{
        mean_results <- apply(current_results, 2, mean)
        top_results <- head(sort(mean_results),min(length(mean_results),5))
        for (m in names(top_results)){
          min_points[[paste(l, w, as.integer(m), sep = "_")]] <- as.numeric(top_results[m])
        }
      }
          allresults[[paste(l, w, sep = "_")]] <- current_results
      
    }
    
  }
  sorted_min_points <- min_points[order(sapply(min_points, function(x) x[1]))]
  return(list(head(sorted_min_points,min(length(min_points),5)),allresults))
}


#'Findbp2: Search the best parameters for SA fitting. 
#'Specifically for learning rate.
#'If fastfitting=TRUE, then the function returns the minimum iterations 
#'allowing less than +3% errors than the minimum error.
#' @export
Findbp2 <- function(ocmat,enmat=NULL,ssize=0.5,lmd=c(0.005),
                    totalit=4000,w=0.001,rep=96,intv=100,threads=16,
                    maxlrs = c(0.002,0.005,0.0075,0.01),
                    runadamW=TRUE,sparse=TRUE,reporting=FALSE,
                    fastfitting=TRUE){
  min_points <- list()
  n_samples <- nrow(ocmat)
  
  randidxs <- sample(n_samples, size = floor(n_samples * ssize), replace = FALSE)
  remaining <- setdiff(1:n_samples, randidxs)
  
  # divide into training and test datasets
  octraining <- ocmat[randidxs,]
  octest <- ocmat[remaining,]
  
  if(!is.null(enmat)){
    envtraining = enmat[randidxs,]
    envtest = enmat[remaining,]
  }
  else{envtest=NULL
  envtraining=NULL}
  
  if(!runadamW){we=c(0)}
  if(!sparse){l=0}
  w = 0.001
  allresults = list()
  for(l in lmd){
    for(maxlr in maxlrs){
      cat(sprintf("Try: l=%.6f, maxlr=%.6f, runadamW=%s, Sparse=%s\n\n",w, maxlr, runadamW, sparse))
      sa_results <- runSA(octraining, enmat=envtraining, rep=rep, threads=threads, we=w, 
                          totalit=totalit, lambda=l,intv=intv, runadamW=runadamW, 
                          sparse=sparse,maxlr=maxlr,getall=TRUE, reporting=reporting)
      current_results <- testfittingSA(octest,sa_results,rep,intv,enmat=envtest)
      # save top results info
      mean_results <- apply(current_results, 2, mean)
      for (m in names(mean_results)){
        min_points[[paste(l, maxlr, as.integer(m), sep = "_")]] <- as.numeric(mean_results[m])
      }
      allresults[[paste(l, maxlr, sep = "_")]] <- current_results
    }
  }
  
  if(fastfitting){
    min_err <- min(unlist(min_points))
    min_points <- min_points[min_points < min_err*1.03]
    sorted_min_points <- min_points[order(sapply(names(min_points),
                                                 function(x) {as.numeric(unlist(strsplit(x,split="_"))[[3]])}))]
  }else{
    sorted_min_points <- min_points[order(sapply(min_points, function(x) x[1]))]
  }
  return(list(head(sorted_min_points,min(length(sorted_min_points),5)),allresults))
}



#'validateSA: to check the predictability of SA results by computing ocmatrix using
#'the estimated parameter set.
validateSA <- function(ocmat,h,j,g=NULL,enmat=NULL){
  if(is.null(enmat)){
    pp <- abs(1 - ocmat - 1 / (1 + exp(t(-h - t(ocmat %*% j)))))
  }
  else{
    pp <- abs(1 - ocmat - 1 / (1 + exp(-t(t(enmat %*% t(g)) + h) - ocmat %*% j)))
    #pp <- abs(1 - ocmat - 1 / (1 + exp(t(t(-hge - (ocmat %*% J))))))
  }
  return( -mean(log(pp[pp > 0])))
}
  

#'plotSAtest: plot the results of SA fitting (Findbp output)
#'@export
plotSAtest <- function(sa_results,ylim=c("auto","auto")){
  res_serials_melt <- as.data.frame(sa_results[[1]]) %>%
    rownames_to_column("rowname") %>%
    gather(key = "timepoint", value = "value", -rowname)
  
  res_serials_melt$timepoint <- as.numeric(res_serials_melt$timepoint)
  summary_df <- res_serials_melt
  summary_df$id <- names(sa_results)[1] 
  if(length(sa_results) > 1){
    for(i in 2:length(sa_results)){
      res_serials_melt <- as.data.frame(sa_results[[i]]) %>%
        rownames_to_column("rowname") %>%
        gather(key = "timepoint", value = "value", -rowname)
      
      res_serials_melt$timepoint <- as.numeric(res_serials_melt$timepoint)
      results_i <- res_serials_melt
      results_i$id <- names(sa_results)[i]
      summary_df <- rbind(summary_df,results_i)
    }
  }
  summary_mean <- summary_df %>%
    group_by(id,timepoint) %>%
    summarise(n = length(value),
              mean=mean(value),
              sd = sd(value)) %>%
    mutate(sem = sd / sqrt(n - 1),
           CI_lower = mean + qt((1-0.95)/2, n - 1) * sem,
           CI_upper = mean - qt((1-0.95)/2, n - 1) * sem)
  
  timepoints = sort(unique(summary_mean$timepoint))
  if(ylim[[1]]=="auto"){
    y1 = min(summary_mean[summary_mean$timepoint==timepoints[length(timepoints)],"mean"])*0.8
  }else{y1 = ylim[[1]]}  
  
  if(ylim[[2]]=="auto"){
    y2 = max(summary_mean[summary_mean$timepoint==timepoints[1],"mean"])*1.2
  }else{y2 = ylim[[2]]}  
  
  if (y2 > y1){
    ymax = y2
    ymin = y1
  }else{
    ymax = y1
    ymin = y2
  }
  
  ggplot(summary_mean, aes(x=timepoint, y=mean, color=id)) +
    geom_line(aes(x=timepoint, y=mean, color=id)) +
    geom_ribbon(aes(ymin=CI_lower,ymax=CI_upper,fill=id),color="grey70",alpha=0.4) +
    scale_y_continuous(limits=c(ymin,ymax))
  
  
}

