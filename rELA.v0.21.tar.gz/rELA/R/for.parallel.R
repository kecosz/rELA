#'Registering prallel
#' @export
#' 
for.parallel <- function (cores = 1) 
{
    require(doParallel)
    cluster = makeCluster(cores)
    return(registerDoParallel(cluster))
}